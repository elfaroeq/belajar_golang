# Lisensi dan Distribusi Konten

Ebook Dasar Pemrograman Go gratis untuk disebarluaskan secara bebas, dengan catatan sesuai dengan aturan lisensi [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0) yang kurang lebih sebagai berikut:

- Diperbolehkan menyebar, mencetak, dan menduplikasi material dalam konten ini ke siapapun.
- Diperbolehkan memodifikasi, mengubah, atau membuat konten baru menggunakan material yang ada dalam ebook ini untuk keperluan komersil maupun tidak.

Dengan catatan:

- Harus ada credit sumber aslinya, yaitu **Dasar Pemrograman Golang** atau **novalagung**
- Tidak mengubah lisensi aslinya, yaitu **CC BY-SA 4.0**
- Tidak ditambahi *restrictions* baru

Lebih jelasnya silakan cek [https://creativecommons.org/licenses/by-sa/4.0/](https://creativecommons.org/licenses/by-sa/4.0/).

[![FOSSA Status](https://app.fossa.io/api/projects/git%2Bgithub.com%2Fnovalagung%2Fdasarpemrogramangolang.svg?type=large)](https://app.fossa.io/projects/git%2Bgithub.com%2Fnovalagung%2Fdasarpemrogramangolang?ref=badge_large)

